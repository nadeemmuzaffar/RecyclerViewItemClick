package com.example.recyleritem;

import android.graphics.Movie;

import com.example.recyleritem.Response.Pojo;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiInterface {
    @GET("marvel")
    Call<List<Pojo>> getData();
}
