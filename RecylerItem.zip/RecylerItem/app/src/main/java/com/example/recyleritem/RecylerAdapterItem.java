package com.example.recyleritem;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.Target;
import com.example.recyleritem.Response.Pojo;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class RecylerAdapterItem extends RecyclerView.Adapter<RecylerAdapterItem.ViewHolder> {

   private ArrayList<Pojo> pojoArrayList;
   private Context context;

    public RecylerAdapterItem(ArrayList<Pojo> pojoArrayList, Context context) {
        this.pojoArrayList = pojoArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public RecylerAdapterItem.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecylerAdapterItem.ViewHolder holder, int position) {
        Pojo pojo=pojoArrayList.get(position);
        holder.tv_name.setText(pojo.getName()+"\n");
        holder.bio.setText(pojo.getBio()+"\n");
        try {
            Glide.with(holder.itemView.getContext()).load(new URL("https://www.simplifiedcoding.net/demos/marvel/captainamerica.jpg"))
                    .into((ImageView) holder.itemView.findViewById(R.id.image));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }


    @Override
    public int getItemCount() {
        return pojoArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tv_name,team,bio;
        ImageView imageView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView=itemView.findViewById(R.id.image);
            tv_name=itemView.findViewById(R.id.tv_name);
            team=itemView.findViewById(R.id.tv_team);
            bio=itemView.findViewById(R.id.tv_bio);

            itemView.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    // get position
                    int pos = getAdapterPosition();
                    if(pos != RecyclerView.NO_POSITION){
                        Pojo clickedDataItem = pojoArrayList.get(pos);
                        Toast.makeText(v.getContext(), "You clicked " + clickedDataItem.getName(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }
}
